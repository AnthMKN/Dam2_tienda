<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                    <div class="card-body">
                        <?php if(strlen (session('status')) > 0): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                                <?php echo e(session(['status' => ''])); ?>

                            </div>
                        <?php endif; ?>

                        <form class="form-floating" action="<?php echo e(route("grupos.storemasiva", ["grupoid" => $grupo->id])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("POST"); ?>
                            <div class="form-group row">
                                <label for="name" class="col-4 col-form-label">Nombre del grupo:</label>
                                <div class="col-8">
                                    <input id="name" name="name" placeholder="nombre del grupo" type="text" class="form-control" value="<?php echo e($grupo->name); ?>" readonly>
                                </div>
                                <?php if($errors->has("name")): ?>
                                    <div class="alert alert-danger" role="alert">
                                        <?php $__currentLoopData = $errors->get("name"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($error1); ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="form-group row">
                                <label class="col-4 col-form-label" for="comentario">Lista de usuarios a meter en el grupo:</label>
                                <div class="col-8">
                                    <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="usuarios[]" id="usuarios[]" value="<?php echo e($usuario->id); ?>"
                                            <?php if(in_array($usuario->id, $amigos)): ?>
                                            <?php echo e("checked"); ?>

                                            <?php endif; ?>
                                            >
                                            <label class="form-check-label" for="<?php echo e($usuario->email); ?>">
                                                <?php echo e($usuario->email); ?>

                                            </label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>





                            <div class="form-group row">
                                <div class="offset-4 col-8">
                                    <button type="submit" class="btn btn-primary">Introducir</button>
                                </div>
                            </div>
                        </form>



                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/laravel/appinicial/resources/views/grupos/intromasiva.blade.php ENDPATH**/ ?>