
<div class="col-lg-4 col-md-6 col-sm-12 p-1 pb-3 m-0">
    <div class="card text-center">
        <div class="card-header">
            Número de participantes: <?php echo e($grupo->participantes->count()); ?>

        </div>
        <div class="card-body">
            <h5 class="card-title"><?php echo e($grupo->name); ?></h5>
            <p class="card-text mb-0"><i class="bi bi-person-lock"></i> <?php echo e($grupo->propietario->name); ?></p>
            <p class="card-text mb-0">Creado el <?php echo e(date("d-m-Y", strtotime($grupo->created_at))); ?></p>


                <?php switch($grupo->estado):
                    case (0): ?>
                        <p class="card-text mb-0"><?php echo e("SIN SORTEAR"); ?></p>
                        <p class="card-text mb-0">Sorteo previsto el <?php echo e(date("d-m-Y", strtotime($grupo->fechasorteo))); ?></p>
                    <?php break; ?>
                    <?php case (1): ?>
                        <p class="card-text mb-0"><?php echo e("Sorteado el " . date("d-m-Y", strtotime($grupo->fechasorteoreal))); ?></p>
                        <p class="card-text mb-0">Entrega de regalos el <?php echo e(date("d-m-Y", strtotime($grupo->fechaentregaregalos))); ?></p>
                    <?php break; ?>
                    <?php case (2): ?>
                        <p class="card-text mb-0"><?php echo e("REGALO ENTREGADO"); ?></p>
                        <?php break; ?>
                <?php endswitch; ?>



            <div class="btn-group btn-group-sm" role="group" aria-label="Basic outlined example">
                <?php if($botonver): ?>
                    <a href="<?php echo e(route('grupos.show', ["grupo" => $grupo->id])); ?>" class="btn btn-outline-primary">Ver</a>
                <?php endif; ?>


<?php if(($grupo->propietario_id == auth()->user()->id)  || (auth()->user()->hasRole("admin"))): ?>
                        <a href="<?php echo e(route("grupos.edit", ["grupo" => $grupo->id])); ?>" class="btn btn-outline-primary">Editar</a>
                        <a href='<?php echo e(route ("grupos.intromasiva",["grupoid" => $grupo->id])); ?>' class="btn btn-outline-primary">Intro</a>
                        <button type="submit" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#borrar<?php echo e($grupo->id); ?>">
                        Borrar
                    </button>
<?php endif; ?>
            </div>

        </div>
        <div class="card-footer">
            <small>Código de acceso: <?php echo e($grupo->codigoacceso); ?></small>
            <?php if($grupo->propietario->id == auth()->user()->id): ?>
                <i class="bi bi-lock"></i>
            <?php endif; ?>
        </div>
    </div>
</div>



<!-- Modal -->
<div class="modal fade" id="borrar<?php echo e($grupo->id); ?>" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Confirmación de borrado</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                 ¿Desea borrar el grupo <strong><?php echo e($grupo->name); ?></strong>?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <form action="<?php echo e(route("grupos.destroy", ["grupo" => $grupo->id])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("DELETE"); ?>
                    <button type="submit" class="btn btn-primary">Borrar</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/vagrant/laravel/appinicial/resources/views/components/tarjetagrupo.blade.php ENDPATH**/ ?>