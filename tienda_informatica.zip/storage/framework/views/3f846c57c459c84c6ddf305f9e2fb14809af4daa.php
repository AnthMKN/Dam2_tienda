<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
                    <a href="<?php echo e(route("grupos.create")); ?>" type="button" class="btn btn-outline-dark">Crear</a>
                    <a href="<?php echo e(route("amigos.create")); ?>" type="button" class="btn btn-outline-dark">Unirse</a>
                </div>

                <div class="card-body">
                    <?php if(strlen (session('status')) > 0): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                            <?php echo e(session(['status' => ''])); ?>

                        </div>
                    <?php endif; ?>

                        <div class="row">


                            <?php $__currentLoopData = auth()->user()->grupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php if (isset($component)) { $__componentOriginal7b8b2c8a496135545a934caed54d92b968f79a80 = $component; } ?>
<?php $component = App\View\Components\Tarjetagrupo::resolve(['grupo' => $grupo,'botonver' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tarjetagrupo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Tarjetagrupo::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b8b2c8a496135545a934caed54d92b968f79a80)): ?>
<?php $component = $__componentOriginal7b8b2c8a496135545a934caed54d92b968f79a80; ?>
<?php unset($__componentOriginal7b8b2c8a496135545a934caed54d92b968f79a80); ?>
<?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/laravel/appinicial/resources/views/home.blade.php ENDPATH**/ ?>