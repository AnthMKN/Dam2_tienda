<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-6">
            <div class="card">
                <div class="card-header">
                    <a href="<?php echo e(route("home")); ?>" type="button" class="btn btn-primary">Volver</a>

                </div>

                <div class="card-body">
                    <?php if(strlen (session('status')) > 0): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                            <?php echo e(session(['status' => ''])); ?>

                        </div>
                    <?php endif; ?>

                </div>

                <?php if (isset($component)) { $__componentOriginal7b8b2c8a496135545a934caed54d92b968f79a80 = $component; } ?>
<?php $component = App\View\Components\Tarjetagrupo::resolve(['grupo' => $grupo,'botonver' => false] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('tarjetagrupo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Tarjetagrupo::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7b8b2c8a496135545a934caed54d92b968f79a80)): ?>
<?php $component = $__componentOriginal7b8b2c8a496135545a934caed54d92b968f79a80; ?>
<?php unset($__componentOriginal7b8b2c8a496135545a934caed54d92b968f79a80); ?>
<?php endif; ?>


                <div class="card-body">
                        <div>
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col">Acción</th>
                                        <th scope="col">Amigo</th>
                                        <th scope="col">Regala a</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $grupo->participantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amigo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php if($grupo->estado == 0): ?>
                                                    <!--- Si es él puede borrarse o si es el admin echar a cualquiera -->
                                                    <?php if(($amigo->id == auth()->user()->id) || ($grupo->propietario_id == auth()->user()->id)): ?>
                                                        <form action="<?php echo e(route('grupos.participantes.destroy', ["grupo" => $grupo->id, "participante" => $amigo->id])); ?>" method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field("delete"); ?>
                                                            <button type="submit" class="btn btn-outline-danger">
                                                                <i class="bi bi-trash3"></i>
                                                            </button>
                                                        </form>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($amigo->id == $grupo->propietario_id): ?>
                                                    <i class="bi bi-person-lock"></i>&nbsp;<?php echo e($amigo->name); ?>

                                                <?php else: ?>
                                                    <?php echo e($amigo->name); ?>

                                                <?php endif; ?>
                                            </td>

                                            <td>
                                                <?php if(($grupo->estado > 0) && (($amigo->id == auth()->user()->id) || ($grupo->propietario_id == auth()->user()->id))): ?>
                                                <?php echo e(\App\Models\User::find($amigo->pivot->amigo_id)->name); ?>

                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </div>
                        <?php if(($grupo->estado == 0) && ($grupo->propietario_id == auth()->user()->id)): ?>
                            <a href="<?php echo e(route('grupos.sortear', ["grupoid" => $grupo->id])); ?>">Sortear</a>
                        <?php endif; ?>
                        <?php if(($grupo->estado == 1) && ($grupo->propietario_id == auth()->user()->id)): ?>
                            <a href="<?php echo e(route('grupos.anularsorteo', ["grupoid" => $grupo->id])); ?>">Anular Sorteo</a>
                        <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/amgelin/Documentos/laravel/appinicial/resources/views/grupos/mostrar.blade.php ENDPATH**/ ?>